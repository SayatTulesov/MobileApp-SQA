package com.example.simpleloginandregistrationapp;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import java.net.MalformedURLException;
import java.net.URL;

public class LoginTest {
    private AppiumDriver driver;

    public LoginTest() {}

    @BeforeTest
    public void setUp() throws MalformedURLException {
        DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
        desiredCapabilities.setCapability("platformName", "ANDROID");
        desiredCapabilities.setCapability("deviceName", "Pixel_3a_API_33_x86_64");
        desiredCapabilities.setCapability("appPackage", "com.example.simpleloginandregistrationapp");
        desiredCapabilities.setCapability("appActivity", ".Login");
        desiredCapabilities.setCapability("automationName", "UiAutomator2");
        URL appiumServerURL = new URL("http://localhost:4723/wd/hub");
        driver = new AndroidDriver(appiumServerURL, desiredCapabilities);
    }

    @Test
    public void LoginFailure() {
        String wrong_username = "sayatushka";
        String wrong_password = "sayatushka";
        String new_username = "sayat1";
        String new_password = "sayat1";

        try {
            Thread.sleep(1000L);
        } catch (InterruptedException var19) {
            var19.printStackTrace();
        }

        WebElement wrong_usernameField = driver.findElement(By.id("et_lusername"));
        wrong_usernameField.sendKeys(wrong_username);

        WebElement wrong_passwordField = driver.findElement(By.id("et_lpassword"));
        wrong_passwordField.sendKeys(wrong_password);

        WebElement wrong_login_button = driver.findElement(By.id("btn_llogin"));
        wrong_login_button.click();

        try {
            Thread.sleep(1000L);
        } catch (InterruptedException var18) {
            var18.printStackTrace();
        }

        WebElement wrong_login_message = driver.findElement(By.xpath("/hierarchy/android.widget.Toast"));
        String expected_wrong_login_welcome_message = "Invalid username or password";
        Assertions.assertEquals(expected_wrong_login_welcome_message, wrong_login_message.getText());

        try {
            Thread.sleep(4000L);
        } catch (InterruptedException var20) {
            var20.printStackTrace();
        }

        WebElement lregister_button = driver.findElement(By.id("btn_lregister"));
        lregister_button.click();

        try {
            Thread.sleep(1000L);
        } catch (InterruptedException var22) {
            var22.printStackTrace();
        }

        WebElement register_usernameField = driver.findElement(By.id("et_username"));
        register_usernameField.sendKeys(new_username);

        WebElement register_passwordField = driver.findElement(By.id("et_password"));
        register_passwordField.sendKeys(new_password);

        WebElement register_confirm_passwordField = driver.findElement(By.id("et_cpassword"));
        register_confirm_passwordField.sendKeys(new_password);

        WebElement register_button = driver.findElement(By.id("btn_register"));
        register_button.click();

        try {
            Thread.sleep(1000L);
        } catch (InterruptedException var21) {
            var21.printStackTrace();
        }

        WebElement message = driver.findElement(By.xpath("/hierarchy/android.widget.Toast"));
        String expected_welcome_message = "Registered";
        Assertions.assertEquals(expected_welcome_message, message.getText());
    }

    @Test
    public void LoginSuccess() {
        String username = "sayat1";
        String password = "sayat1";

        WebElement login_button = driver.findElement(By.id("btn_login"));
        login_button.click();

        try {
            Thread.sleep(1000L);
        } catch (InterruptedException var10) {
            var10.printStackTrace();
        }

        WebElement usernameField = driver.findElement(By.id("et_lusername"));
        usernameField.sendKeys(username);

        WebElement passwordField = driver.findElement(By.id("et_lpassword"));
        passwordField.sendKeys(password);

        WebElement lloginButton = driver.findElement(By.id("btn_llogin"));
        lloginButton.click();

        try {
            Thread.sleep(2000L);
        } catch (InterruptedException var8) {
            var8.printStackTrace();
        }

        WebElement message = driver.findElement(By.xpath("/hierarchy/android.widget.Toast"));
        String expected_welcome_message = "Login Successful";
        Assertions.assertEquals(expected_welcome_message, message.getText());
    }

    @AfterTest
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}