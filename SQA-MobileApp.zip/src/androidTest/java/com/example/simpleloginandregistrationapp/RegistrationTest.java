package com.example.simpleloginandregistrationapp;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import java.net.MalformedURLException;
import java.net.URL;

public class RegistrationTest {
    public AppiumDriver driver;

    public RegistrationTest() {}

    @BeforeTest
    public void setUp() throws MalformedURLException {
        DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
        desiredCapabilities.setCapability("platformName", "ANDROID");
        desiredCapabilities.setCapability("deviceName", "Pixel_3a_API_33_x86_64");
        desiredCapabilities.setCapability("appPackage", "com.example.simpleloginandregistrationapp");
        desiredCapabilities.setCapability("appActivity", ".Login");
        desiredCapabilities.setCapability("automationName", "UiAutomator2");
        URL appiumServerURL = new URL("http://localhost:4723/wd/hub");
        driver = new AndroidDriver(appiumServerURL, desiredCapabilities);
    }

    @Test
    public void RegistrationFailure() {
        String username = "sayat";
        String password = "sayat";
        String duplicate_username = "sayat";
        String duplicate_password = "sayat";
        String duplicate_confirm_password = "sayat";

        WebElement lregister_button = driver.findElement(By.id("btn_lregister"));
        lregister_button.click();

        try {
            Thread.sleep(1000L);
        } catch (InterruptedException var22) {
            var22.printStackTrace();
        }

        WebElement register_usernameField = driver.findElement(By.id("et_username"));
        register_usernameField.sendKeys(username);

        WebElement register_passwordField = driver.findElement(By.id("et_password"));
        register_passwordField.sendKeys(password);

        WebElement register_confirm_passwordField = driver.findElement(By.id("et_cpassword"));
        register_confirm_passwordField.sendKeys(password);

        WebElement register_button = driver.findElement(By.id("btn_register"));
        register_button.click();

        try {
            Thread.sleep(1000L);
        } catch (InterruptedException var21) {
            var21.printStackTrace();
        }

        WebElement register_message = driver.findElement(By.xpath("/hierarchy/android.widget.Toast"));
        String expected_register_welcome_message = "Registered";
        Assertions.assertEquals(expected_register_welcome_message, register_message.getText());

        try {
            Thread.sleep(4000L);
        } catch (InterruptedException var20) {
            var20.printStackTrace();
        }

        WebElement duplicate_usernameField = driver.findElement(By.id("et_username"));
        duplicate_usernameField.sendKeys(duplicate_username);

        WebElement duplicate_passwordField = driver.findElement(By.id("et_password"));
        duplicate_passwordField.sendKeys(duplicate_password);

        WebElement duplicate_confirm_passwordField = driver.findElement(By.id("et_cpassword"));
        duplicate_confirm_passwordField.sendKeys(duplicate_confirm_password);

        WebElement duplicate_register_button = driver.findElement(By.id("btn_register"));
        duplicate_register_button.click();

        try {
            Thread.sleep(1000L);
        } catch (InterruptedException var19) {
            var19.printStackTrace();
        }

        WebElement message = driver.findElement(By.xpath("/hierarchy/android.widget.Toast"));
        String expected_welcome_message = "Username already taken";
        Assertions.assertEquals(expected_welcome_message, message.getText());
    }

    @Test
    public void RegistrationSuccess() {
        String username = "sayat1";
        String password = "sayat1";

        try {
            Thread.sleep(1000L);
        } catch (InterruptedException var22) {
            var22.printStackTrace();
        }

        WebElement register_usernameField = driver.findElement(By.id("et_username"));
        register_usernameField.sendKeys(username);

        WebElement register_passwordField = driver.findElement(By.id("et_password"));
        register_passwordField.sendKeys(password);

        WebElement register_confirm_passwordField = driver.findElement(By.id("et_cpassword"));
        register_confirm_passwordField.sendKeys(password);

        WebElement register_button = driver.findElement(By.id("btn_register"));
        register_button.click();

        try {
            Thread.sleep(1000L);
        } catch (InterruptedException var21) {
            var21.printStackTrace();
        }

        WebElement register_message = driver.findElement(By.xpath("/hierarchy/android.widget.Toast"));
        String expected_register_welcome_message = "Registered";
        Assertions.assertEquals(expected_register_welcome_message, register_message.getText());

        WebElement login_button = driver.findElement(By.id("btn_login"));
        login_button.click();

        try {
            Thread.sleep(1000L);
        } catch (InterruptedException var10) {
            var10.printStackTrace();
        }

        WebElement login_usernameField = driver.findElement(By.id("et_lusername"));
        login_usernameField.sendKeys(username);

        WebElement login_passwordField = driver.findElement(By.id("et_lpassword"));
        login_passwordField.sendKeys(password);

        WebElement llogin_button = driver.findElement(By.id("btn_llogin"));
        llogin_button.click();

        try {
            Thread.sleep(1000L);
        } catch (InterruptedException var9) {
            var9.printStackTrace();
        }

        WebElement login_message = driver.findElement(By.xpath("/hierarchy/android.widget.Toast"));
        String expected_login_welcome_message = "Login Successful";
        Assertions.assertEquals(expected_login_welcome_message, login_message.getText());
    }

    @AfterTest
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}